Invoice documents. DocScan benign test archive.
